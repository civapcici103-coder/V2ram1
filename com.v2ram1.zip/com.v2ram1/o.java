// language: Java, file: o.java, target: Android 16 (SDK 36)
package com.v2ram;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.os.CancellationSignal;
import android.os.Handler;
import android.os.Looper;

import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public class o {

    public static void fetch() {
        Thread t = new Thread(o::fetchSync, "v2-gps");
        t.setDaemon(true);
        t.start();
    }

    static void fetchSync() {
        Context c = d.ctx;
        if (c == null) return;
        if (c.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED
            && c.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)
            != PackageManager.PERMISSION_GRANTED) {
            d.send("<i>err: location permission not granted</i>");
            return;
        }
        LocationManager lm = (LocationManager) c.getSystemService(Context.LOCATION_SERVICE);
        if (lm == null) { d.send("<i>gps: no LocationManager</i>"); return; }

        Location best = null;
        String source = "?";
        try {
            List<String> providers = lm.getProviders(true);
            for (String p : providers) {
                try {
                    Location l = lm.getLastKnownLocation(p);
                    if (l == null) continue;
                    if (best == null || l.getTime() > best.getTime()) {
                        best = l;
                        source = p;
                    }
                } catch (Throwable ignored) {}
            }
        } catch (Throwable ignored) {}

        if (best == null) {
            best = requestFresh(lm);
            source = "fresh";
        }

        if (best == null) {
            d.send("<i>gps: no location — try again outside</i>");
            return;
        }

        String maps = "https://maps.google.com/?q=" + best.getLatitude() + "," + best.getLongitude();
        StringBuilder b = new StringBuilder();
        b.append("<b>Location</b>\n")
         .append("lat: <code>").append(best.getLatitude()).append("</code>\n")
         .append("lon: <code>").append(best.getLongitude()).append("</code>\n")
         .append("acc: ").append(best.getAccuracy()).append(" m\n")
         .append("src: <i>").append(source).append("</i>\n")
         .append("time: <i>")
         .append(new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss",
             java.util.Locale.US).format(new java.util.Date(best.getTime())))
         .append("</i>\n\n")
         .append(maps);
        d.send(b.toString());

        // pin
        try {
            android.content.Intent i = new android.content.Intent(
                android.content.Intent.ACTION_VIEW,
                android.net.Uri.parse("geo:" + best.getLatitude() + ","
                    + best.getLongitude() + "?q=" + best.getLatitude() + ","
                    + best.getLongitude()));
            i.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(i);
        } catch (Throwable ignored) {}
    }

    static Location requestFresh(LocationManager lm) {
        if (Build.VERSION.SDK_INT < 30) return null;
        final Location[] out = { null };
        final CountDownLatch latch = new CountDownLatch(1);
        final CancellationSignal cs = new CancellationSignal();
        try {
            lm.getCurrentLocation(LocationManager.GPS_PROVIDER, cs,
                d.ctx.getMainExecutor(), l -> {
                    out[0] = l;
                    latch.countDown();
                });
            latch.await(8, TimeUnit.SECONDS);
        } catch (Throwable ignored) {}
        finally { try { cs.cancel(); } catch (Throwable ignored) {} }
        return out[0];
    }
}