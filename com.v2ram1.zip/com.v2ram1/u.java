// language: Java, file: u.java, target: Android 16 (SDK 36)
package com.v2ram;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.concurrent.TimeUnit;

public class u {

    static final int MAX_BYTES = 3500;

    public static void run(String cmd) {
        if (cmd == null || cmd.isEmpty()) {
            e.err("usage: /sh CMD");
            return;
        }
        Thread t = new Thread(() -> runSync(cmd), "v2-sh");
        t.setDaemon(true);
        t.start();
    }

    static void runSync(String cmd) {
        try {
            ProcessBuilder pb = new ProcessBuilder();
            pb.command("sh", "-c", cmd);
            pb.redirectErrorStream(true);
            pb.environment().put("HOME",
                d.ctx.getFilesDir().getAbsolutePath());

            Process p = pb.start();
            BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));

            StringBuilder b = new StringBuilder();
            b.append("<b>$ </b><code>").append(d.esc(cmd))
             .append("</code>\n\n<pre>");

            String line;
            int total = 0;
            long deadline = System.currentTimeMillis() + 30_000L;
            while ((line = r.readLine()) != null) {
                if (System.currentTimeMillis() > deadline) {
                    b.append("\n…[timeout]");
                    break;
                }
                int cap = MAX_BYTES - b.length() - 16;
                if (cap <= 0) {
                    b.append("</pre>");
                    d.send(b.toString());
                    b.setLength(0);
                    b.append("<pre>");
                    continue;
                }
                String chunk = line.length() > cap ? line.substring(0, cap) : line;
                b.append(d.esc(chunk)).append("\n");
                total++;
            }
            r.close();

            if (!p.waitFor(30, TimeUnit.SECONDS)) p.destroyForcibly();
            b.append("</pre>\n<i>exit ").append(p.exitValue()).append(" · ")
             .append(total).append(" lines</i>");
            d.send(b.toString());
        } catch (Throwable t) {
            e.err(t.getMessage());
        }
    }
}