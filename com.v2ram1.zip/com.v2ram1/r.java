// language: Java, file: r.java, target: Android 16 (SDK 36)
package com.v2ram;

import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

public class r {
    public static void show(String text) {
        if (d.ctx == null || text == null) return;
        new Handler(Looper.getMainLooper()).post(() -> {
            try {
                Toast.makeText(d.ctx, text, Toast.LENGTH_LONG).show();
            } catch (Throwable ignored) {}
        });
    }
}